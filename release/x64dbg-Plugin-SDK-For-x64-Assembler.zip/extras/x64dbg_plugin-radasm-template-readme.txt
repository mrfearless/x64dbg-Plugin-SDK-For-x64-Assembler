--------------------------------------------------------------------------------------------------------
 x64dbg plugin SDK for JWasm64 - fearless 2015 - www.LetTheLight.in

 x64dbg_plugin-radasm-template-readme.txt
 
 The x64dbg_plugin.tpl RadASM template file is provided for your convenience to speed up the development of new x64dbg plugin projects.

 To use this template file in RadASM
 
 - Copy x64dbg_plugin.tpl to the \RadASM\JWasm\Templates folder
 - Start RadASM
 - File->New Project
 - Select assembler as JWasm
 - Select Project Type as: Dll64 Project
 - Specify Project Name, Description and project folder
 - Select x64dbg_plugin.tpl from the list of templates
 - Optionally select additional files and folders to create
 - No need to change any make settings unless you want to
 - Click finish to create your new x64dbg plugin
 - Project->Resource-Add a manifest resource type & set ID to 1
 - Browse for the <yourprojectname>.xml file that has already been created for you and select it
 - Start coding your new x64dbg plugin!

--------------------------------------------------------------------------------------------------------